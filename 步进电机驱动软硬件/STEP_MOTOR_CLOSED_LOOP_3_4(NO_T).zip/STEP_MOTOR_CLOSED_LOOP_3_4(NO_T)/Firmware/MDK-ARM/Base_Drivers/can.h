#ifndef __CAN_H
#define __CAN_H
#include "gd32f10x.h"
#include "gd32f10x_gpio.h"
#include <stdbool.h>

typedef enum{
	CAN_EMPTY				= 0x00,	//���߿���
	CAN_FULL			  = 0x01,	//����ռ��
}CANBUS_State;

typedef struct{
	CANBUS_State canbus_state;
	bool CAN_R_W_State;		 //1������ 
}CAN_State;
typedef struct {
	uint32_t can_id;
	uint8_t can_dlc;
	uint8_t data[8];
} CanFrame;
extern CanFrame canrecevie_frame;
typedef struct _CAN_READ{
	// Motor
	short motor_ENABLE;
	short motor_address;
	short control_mode;
	short parameter_memory_flag;
	unsigned short calib_flag;
	unsigned short op_state;			
	// Control
	unsigned short traj_accel;					
	unsigned short traj_decel;				
	short dce_kp;																
	short dce_ki;																
	short dce_kv;																
	short dce_kd;							
	short vel_max;						
	short current_max;			  
	// Protect
	short protect_under_voltage;	

	//ֻд����FLASH��
	short velocity_target;											
	short Motor_IS_target;											
	//ֻ��(��FLASH)
	short velocity_current;										
	short Motor_IS;
	int 	position_current;										
	int 	position_target;											
	
		
	
} CAN_READ;
extern CAN_READ can_read;
extern CAN_State can_state;
void Refresh_Parameters(void);
void CAN_Read_Parameters(void);
void CAN_init(void);
bool can_send(uint32_t frameID, uint8_t* pData, uint8_t len);
bool CAN_receive(CanFrame *rx_frame);
#endif

