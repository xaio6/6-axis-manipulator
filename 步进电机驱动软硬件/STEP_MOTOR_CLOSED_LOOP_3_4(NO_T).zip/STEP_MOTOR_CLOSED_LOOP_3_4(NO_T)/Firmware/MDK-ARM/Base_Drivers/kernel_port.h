/******
	************************************************************************
	******
	** @project : XDrive_Step
	** @brief   : Stepper motor with multi-function interface and closed loop function. 
	** @brief   : 具有多功能接口和闭环功能的步进电机
	** @author  : unlir (知不知啊)
	** @contacts: QQ.1354077136
	******
	** @address : https://github.com/unlir/XDrive
	******
	************************************************************************
	******
	** {Stepper motor with multi-function interface and closed loop function.}
	** Copyright (c) {2020}  {unlir(知不知啊)}
	** 
	** This program is free software: you can redistribute it and/or modify
	** it under the terms of the GNU General Public License as published by
	** the Free Software Foundation, either version 3 of the License, or
	** (at your option) any later version.
	** 
	** This program is distributed in the hope that it will be useful,
	** but WITHOUT ANY WARRANTY; without even the implied warranty of
	** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	** GNU General Public License for more details.
	** 
	** You should have received a copy of the GNU General Public License
	** along with this program.  If not, see <http://www.gnu.org/licenses/>.
	******
	************************************************************************
******/


/*****
  ** @file     : kernel_port.c/h
  ** @brief    : 端口定义
  ** @versions : newest
  ** @time     : newest
  ** @reviser  : unli (HeFei China)
  ** @explain  : null
*****/

#ifndef KERNEL_PORT_H
#define KERNEL_PORT_H


#define HW_ELEC_AP_GPIO_Port						(GPIOA)
#define HW_ELEC_AP_Pin									(GPIO_PIN_7)
#define HW_ELEC_AM_GPIO_Port						(GPIOB)
#define HW_ELEC_AM_Pin									(GPIO_PIN_1)
#define HW_ELEC_BP_GPIO_Port						(GPIOB)
#define HW_ELEC_BP_Pin									(GPIO_PIN_6)
#define HW_ELEC_BM_GPIO_Port						(GPIOB)
#define HW_ELEC_BM_Pin									(GPIO_PIN_7)
//GPIO输出
#define Out_AP_H()		gpio_bit_set(GPIOA, HW_ELEC_AP_Pin)
#define Out_AP_L()		gpio_bit_reset(GPIOA, HW_ELEC_AP_Pin)
#define Out_AM_H()		gpio_bit_set(GPIOB, HW_ELEC_AM_Pin)
#define Out_AM_L()		gpio_bit_reset(GPIOB, HW_ELEC_AM_Pin)
#define Out_BP_H()		gpio_bit_set(GPIOB, HW_ELEC_BP_Pin)
#define Out_BP_L()		gpio_bit_reset(GPIOB, HW_ELEC_BP_Pin)
#define Out_BM_H()		gpio_bit_set(GPIOB, HW_ELEC_BM_Pin)
#define Out_BM_L()		gpio_bit_reset(GPIOB, HW_ELEC_BM_Pin)
//TIM输出
#define Out_PWMtoDAC_A(value)		TIM1_REGISTER_P->CCR4 = value
#define Out_PWMtoDAC_B(value)		TIM1_REGISTER_P->CCR3 = value
//C基本库
#include <stdbool.h>	//Bool数据类型

#include "main.h"
#include "tim.h"


#endif
