
#include "can.h"
#include "motor_control.h"
#include "USER_Config.h"
#include "peripheral.h"		

short *can_send_reg;
unsigned char reg_adg = 0;
void CAN_init(void)
{
	can_parameter_struct can_parameter;
	 can_filter_parameter_struct can_filter;
	/* enable CAN clock */
    rcu_periph_clock_enable(RCU_CAN0);
    rcu_periph_clock_enable(RCU_GPIOB);
    rcu_periph_clock_enable(RCU_AF);
    
    /* configure CAN0 GPIO */

		gpio_init(GPIOB, GPIO_MODE_IPU, GPIO_OSPEED_50MHZ, GPIO_PIN_8);	// CAN_RX
		gpio_init(GPIOB, GPIO_MODE_AF_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_9);	// CAN_TX
		gpio_pin_remap_config(GPIO_CAN_PARTIAL_REMAP,ENABLE);
		can_struct_para_init(CAN_INIT_STRUCT, &can_parameter);
		can_deinit(CAN0);
	


    /* initialize CAN register */
    can_deinit(CAN0);
    
    /* initialize CAN */
    can_parameter.time_triggered = DISABLE;
    can_parameter.auto_bus_off_recovery = DISABLE;
    can_parameter.auto_wake_up = DISABLE;
    can_parameter.auto_retrans = DISABLE;
    can_parameter.rec_fifo_overwrite = DISABLE;
    can_parameter.trans_fifo_order = DISABLE;
    can_parameter.working_mode = CAN_NORMAL_MODE;
    can_parameter.resync_jump_width = CAN_BT_SJW_1TQ;
    can_parameter.time_segment_1 = CAN_BT_BS1_5TQ;
    can_parameter.time_segment_2 = CAN_BT_BS2_3TQ;
    /* baudrate 1Mbps */
    can_parameter.prescaler = 6;
    can_init(CAN0, &can_parameter);

    /* initialize filter */
    /* CAN0 filter number */
    can_filter.filter_number = 0;

    /* initialize filter */
    can_filter.filter_mode = CAN_FILTERMODE_MASK;
    can_filter.filter_bits = CAN_FILTERBITS_32BIT;
    can_filter.filter_list_high = 0x0000;
    can_filter.filter_list_low = 0x0000;
    can_filter.filter_mask_high = 0x0000;
    can_filter.filter_mask_low = 0x0000;  
    can_filter.filter_fifo_number = CAN_FIFO0;
    can_filter.filter_enable = ENABLE;
    can_filter_init(&can_filter);
		can_send_reg = (short *)&can_read;
		reg_adg = 0;
		
		g_transmit_message.tx_efid = 0x00;
		g_transmit_message.tx_ft = CAN_FT_DATA;
		g_transmit_message.tx_ff = CAN_FF_STANDARD;
		g_transmit_message.tx_dlen = 8; 

}

void Refresh_Parameters()
{
	can_state.CAN_R_W_State = 1;
	can_read.velocity_current                     = motor_control.est_speed/51200;
	can_read.position_current 										= motor_control.real_location;
	

	if(motor_control.state == Control_State_Finish)
	{
		g_transmit_message.tx_data[0] = can_read.motor_address;
		g_transmit_message.tx_data[0] |= (canrecevie_frame.data[0]<<4);
	}else
	{
		g_transmit_message.tx_data[0] = 0;
		g_transmit_message.tx_data[0] |= (canrecevie_frame.data[0]<<4);
	}
	g_transmit_message.tx_data[1] = canrecevie_frame.data[1];//���ؼĴ�����ַ
	g_transmit_message.tx_data[2] = ((*(can_send_reg+canrecevie_frame.data[1]))>>8);
	g_transmit_message.tx_data[3] = (*can_send_reg);
	g_transmit_message.tx_data[4] = can_read.position_current>>24;
	g_transmit_message.tx_data[5] = can_read.position_current>>16;
	g_transmit_message.tx_data[6] = can_read.position_current>>8;
	g_transmit_message.tx_data[7] = can_read.position_current;

}
float  angl_e = 0;
void CAN_Read_Parameters()
{
	switch(canrecevie_frame.data[0])
	{
		case 0:	//����
			{
				Refresh_Parameters();		
			}
		break;
		case 1:
			{
				Refresh_Parameters();

			}
			break;
		case 2:
			{
				char inc = canrecevie_frame.data[1];
				
				(*(can_send_reg+inc)) 		 = canrecevie_frame.data[2]<<8;
				(*(can_send_reg+inc)) 	  += canrecevie_frame.data[3];
				can_read.position_target  = canrecevie_frame.data[4]<<24;
				can_read.position_target += canrecevie_frame.data[5]<<16;
				can_read.position_target += canrecevie_frame.data[6]<<8;
				can_read.position_target += canrecevie_frame.data[7];
				motor_control.soft_location = can_read.position_target;
				motor_control.soft_speed = (float)can_read.velocity_target*853.3f;
				if((motor_control.soft_location<motor_control.real_location)&&(motor_control.soft_speed>0))
				{
					motor_control.soft_speed = -motor_control.soft_speed;
				}
				if((motor_control.soft_location>motor_control.real_location)&&(motor_control.soft_speed<0))
				{
					motor_control.soft_speed = -motor_control.soft_speed;
				}	
			}
			break;
			case 3:
			{
				char inc = canrecevie_frame.data[1];
				(*(can_send_reg+inc)) 		 = canrecevie_frame.data[2]<<8;
				(*(can_send_reg+inc)) 	  += canrecevie_frame.data[3];
				if(can_read.motor_ENABLE == 0)
				{
					PWMC_switch_down_pwm();
				}else
					{
						Control_DCE_Init();
						motor_control.soft_location = motor_control.real_location;
						PWMC_switch_on_pwm();	
					}
				g_transmit_message.tx_data[4] = 0;
				if(canrecevie_frame.data[4] == 0x12)
				{
					g_transmit_message.tx_sfid    = can_read.motor_address;
					Parameter_Save();
					g_transmit_message.tx_data[4] = 1;
				}
				if(can_read.op_state == 0x01)
				{
					magnet_1;
				}else if(can_read.op_state == 0x00)
				{
					magnet_0;
				}
				g_transmit_message.tx_data[5] = 0;
				g_transmit_message.tx_data[6] = 0;
				g_transmit_message.tx_data[7] = 0;
				Refresh_Parameters();
			}
			break;
			case 4:
			{

			}
			break;

}
}

bool can_send(uint32_t frameID, uint8_t* pData, uint8_t len)
{
	uint8_t mailbox_number = CAN_MAILBOX0;
	
	/* select one empty mailbox */
    if(CAN_TSTAT_TME0 == (CAN_TSTAT(CAN0)&CAN_TSTAT_TME0)){
        mailbox_number = CAN_MAILBOX0;
    }else if(CAN_TSTAT_TME1 == (CAN_TSTAT(CAN0)&CAN_TSTAT_TME1)){
        mailbox_number = CAN_MAILBOX1;
    }else if(CAN_TSTAT_TME2 == (CAN_TSTAT(CAN0)&CAN_TSTAT_TME2)){
        mailbox_number = CAN_MAILBOX2;
    }else{
        mailbox_number = CAN_NOMAILBOX;
    }
    /* return no mailbox empty */
    if(CAN_NOMAILBOX == mailbox_number){
        return 0;
    }
	
	/* set transmit mailbox standard identifier */
	CAN_TMI(CAN0, mailbox_number) = (uint32_t)(TMI_SFID(frameID & 0x7FF));
	
	/* set the data length */
	CAN_TMP(CAN0, mailbox_number) &= ~(CAN_TMP_DLENC);
	CAN_TMP(CAN0, mailbox_number) |= len & 0x0F;
	if(pData[2] == 0)
	{
//	int c = 0;
//		c = 10;
	}
	/* set the data */
	CAN_TMDATA0(CAN0, mailbox_number) = TMDATA0_DB3(pData[3]) | \
											  TMDATA0_DB2(pData[2]) | \
											  TMDATA0_DB1(pData[1]) | \
											  TMDATA0_DB0(pData[0]);
	CAN_TMDATA1(CAN0, mailbox_number) = TMDATA1_DB7(pData[7]) | \
											  TMDATA1_DB6(pData[6]) | \
											  TMDATA1_DB5(pData[5]) | \
											  TMDATA1_DB4(pData[4]);
	
	/* enable transmission */
    CAN_TMI(CAN0, mailbox_number) |= CAN_TMI_TEN;
	
	return 1;
}
bool CAN_receive(CanFrame *rx_frame)
{
	if ((CAN_RFIFO0(CAN0) & CAN_RFIF_RFL_MASK) != 0) {
		rx_frame->can_id = GET_RFIFOMI_SFID(CAN_RFIFOMI(CAN0, 0));
		rx_frame->can_dlc = (uint8_t)(GET_RFIFOMP_DLENC(CAN_RFIFOMP(CAN0, 0)));
		can_state.CAN_R_W_State = 0;
		if((g_transmit_message.tx_sfid == rx_frame->can_id)||(rx_frame->can_id == 0))
		{
			rx_frame->data[0] = (uint8_t)(GET_RFIFOMDATA0_DB0(CAN_RFIFOMDATA0(CAN0, 0)));
			rx_frame->data[1] = (uint8_t)(GET_RFIFOMDATA0_DB1(CAN_RFIFOMDATA0(CAN0, 0)));
			rx_frame->data[2] = (uint8_t)(GET_RFIFOMDATA0_DB2(CAN_RFIFOMDATA0(CAN0, 0)));
			rx_frame->data[3] = (uint8_t)(GET_RFIFOMDATA0_DB3(CAN_RFIFOMDATA0(CAN0, 0)));
			rx_frame->data[4] = (uint8_t)(GET_RFIFOMDATA1_DB4(CAN_RFIFOMDATA1(CAN0, 0)));
			rx_frame->data[5] = (uint8_t)(GET_RFIFOMDATA1_DB5(CAN_RFIFOMDATA1(CAN0, 0)));
			rx_frame->data[6] = (uint8_t)(GET_RFIFOMDATA1_DB6(CAN_RFIFOMDATA1(CAN0, 0)));
			rx_frame->data[7] = (uint8_t)(GET_RFIFOMDATA1_DB7(CAN_RFIFOMDATA1(CAN0, 0)));

			
			CAN_RFIFO0(CAN0) |= CAN_RFIFO0_RFD0; // release FIFO
			CAN_Read_Parameters();
			return false;				
		}else{
		
			can_state.canbus_state = CAN_FULL; 
			CAN_RFIFO0(CAN0) |= CAN_RFIFO0_RFD0; // release FIFO
		return false;}

	} else {
		can_state.canbus_state = CAN_EMPTY;
		return true;
	}
}

