/******
	************************************************************************
	******
	** @project : XDrive_Step
	** @brief   : Stepper motor with multi-function interface and closed loop function. 
	** @brief   : 具有多功能接口和闭环功能的步进电机
	** @author  : unlir (知不知啊)
	** @contacts: QQ.1354077136
	******
	** @address : https://github.com/unlir/XDrive
	******
	************************************************************************
	******
	** {Stepper motor with multi-function interface and closed loop function.}
	** Copyright (c) {2020}  {unlir(知不知啊)}
	** 
	** This program is free software: you can redistribute it and/or modify
	** it under the terms of the GNU General Public License as published by
	** the Free Software Foundation, either version 3 of the License, or
	** (at your option) any later version.
	** 
	** This program is distributed in the hope that it will be useful,
	** but WITHOUT ANY WARRANTY; without even the implied warranty of
	** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	** GNU General Public License for more details.
	** 
	** You should have received a copy of the GNU General Public License
	** along with this program.  If not, see <http://www.gnu.org/licenses/>.
	******
	************************************************************************
******/

/*****
  ** @file     : mt6816.c/h
  ** @brief    : MT6816传感器硬件驱动
  ** @versions : 1.1.1
  ** @time     : 2020/08/01
  ** @reviser  : unli (HeFei China)
  ** @explain  : null
*****/

//Oneself
#include "mt6816.h"
#include "encoder.h"
//Config
#include "encode_cali.h"
//Control
#include "control_config.h"



//GPIO输出
#define NCS_SET()		GPIO_BOP(GPIOA) = (uint32_t)GPIO_PIN_15;
#define NCS_RESET()		GPIO_BC(GPIOA) = (uint32_t)GPIO_PIN_15;
#define GPIOA_ODR_Addr    (GPIOA+12) //0x4001100C 
#define BITBAND(addr, bitnum) ((addr & 0xF0000000)+0x2000000+((addr &0xFFFFF)<<5)+(bitnum<<2)) 
#define MEM_ADDR(addr)  *((volatile unsigned long  *)(addr)) 
#define BIT_ADDR(addr, bitnum)   MEM_ADDR(BITBAND(addr, bitnum)) 
#define PAout(n)   BIT_ADDR(GPIOA_ODR_Addr,n)  //输出 
#define SPI_CS_ENABLE		PAout(15)	//485模式控制.0,接收;1,发送.
MT6816_SPI_Signal_Typedef mt6816_spi;



/**
  * @brief  MT6816_SPI采集初始化
  * @param  NULL
  * @retval NULL
**/
void REIN_MT6816_SPI_Signal_Init(void)
{
	//采集数据
	mt6816_spi.sample_data = 0;
	//输出数据
	mt6816_spi.angle = 0;
	
}

/** 
  * @brief  MT6816_SPI采集获取角度数据
  * @param  NULL
  * @retval NULL
**/
static uint16_t bsp_enc_spi_rw(uint16_t dat)
{
    uint16_t res;
SPI_CS_ENABLE = 0;
		while(spi_i2s_flag_get(SPI0, SPI_FLAG_TBE) == RESET);

    spi_i2s_data_transmit(SPI0, dat);
		while(spi_i2s_flag_get(SPI0, SPI_FLAG_RBNE) == RESET);

    res = spi_i2s_data_receive(SPI0);

    return res;
}
uint8_t r_[6];  unsigned int angle = 0; 
void RINE_MT6816_SPI_Get_AngleData(void)
{
	NCS_SET();	
	SPI_CS_ENABLE = 0;
	bsp_enc_spi_rw(0x03);

	bsp_enc_spi_rw(0x04);
	r_[0] = bsp_enc_spi_rw(0xff);//0x12/0xff*100k
	r_[1] = bsp_enc_spi_rw(0xff);//0x12/0xff*100k
	r_[2] = bsp_enc_spi_rw(0xff);//0x12/0xff*100k	
	angle=((r_[0]<<16)|(r_[1]<<8)|(r_[2]));	
	angle >>= 9;
	SPI_CS_ENABLE = 1;
	mt6816_spi.angle = angle;

}


/****************************** MT6816 ******************************/
/****************************** MT6816 ******************************/
/****************************** MT6816 ******************************/
MT6816_Typedef	mt6816;



/**
  * @brief  MT6816获取角度数据
  * @param  NULL
  * @retval NULL
**/



















