#ifndef PERIPHERAL_H
#define PERIPHERAL_H

#include "kernel_port.h"
#define magnet_1 gpio_bit_set(GPIOA,GPIO_PIN_12);	
#define magnet_0 gpio_bit_reset(GPIOA,GPIO_PIN_12);	


void port_init(void);

#endif

