

#include "tim.h"

void REIN_TIM_HwElec_Init(void)
{

		timer_parameter_struct timer_initpara;
		timer_oc_parameter_struct timer_ocinitpara;


		rcu_periph_clock_enable(RCU_AF);
		gpio_pin_remap_config(GPIO_TIMER1_FULL_REMAP,ENABLE);
		rcu_periph_clock_enable(RCU_GPIOA);
		rcu_periph_clock_enable(RCU_GPIOB);	
		rcu_periph_clock_enable(RCU_TIMER1);

		gpio_init(HW_ELEC_AP_GPIO_Port, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, HW_ELEC_AP_Pin);
		gpio_init(HW_ELEC_AM_GPIO_Port, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, HW_ELEC_AM_Pin);
		gpio_init(HW_ELEC_AM_GPIO_Port, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, HW_ELEC_BP_Pin);
		gpio_init(HW_ELEC_AM_GPIO_Port, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, HW_ELEC_BM_Pin);	
	
		gpio_init(GPIOB, GPIO_MODE_AF_PP, GPIO_OSPEED_50MHZ, HW_ELEC_APWM_Pin);
		gpio_init(GPIOB, GPIO_MODE_AF_PP, GPIO_OSPEED_50MHZ, HW_ELEC_BPWM_Pin);

    timer_deinit(TIMER1);
    timer_struct_para_init(&timer_initpara);
    timer_initpara.prescaler         = 0;
    timer_initpara.alignedmode       = TIMER_COUNTER_EDGE;
    timer_initpara.counterdirection  = TIMER_COUNTER_UP;
    timer_initpara.period            = (1024-1);
    timer_initpara.clockdivision     = TIMER_CKDIV_DIV1;
    timer_initpara.repetitioncounter = 0;
    timer_init(TIMER1, &timer_initpara);


	
		timer_channel_output_struct_para_init(&timer_ocinitpara);//初始化通道
		timer_ocinitpara.outputstate  = TIMER_CCX_ENABLE;
		timer_ocinitpara.outputnstate = TIMER_CCXN_ENABLE;
		timer_ocinitpara.ocpolarity   = TIMER_OC_POLARITY_HIGH;
		timer_ocinitpara.ocidlestate  = TIMER_OC_IDLE_STATE_LOW;
		timer_channel_output_config(TIMER1, TIMER_CH_2, &timer_ocinitpara);
		timer_channel_output_config(TIMER1, TIMER_CH_3, &timer_ocinitpara);

    timer_channel_output_pulse_value_config(TIMER1, TIMER_CH_2, 100);
    timer_channel_output_mode_config(TIMER1, TIMER_CH_2, TIMER_OC_MODE_PWM0);

    timer_channel_output_pulse_value_config(TIMER1, TIMER_CH_3,100);
    timer_channel_output_mode_config(TIMER1, TIMER_CH_3, TIMER_OC_MODE_PWM0);

		timer_channel_output_state_config(TIMER1, TIMER_CH_2, TIMER_CCX_ENABLE);
		timer_channel_output_state_config(TIMER1, TIMER_CH_3, TIMER_CCX_ENABLE);
		timer_primary_output_config(TIMER1,ENABLE);
		timer_auto_reload_shadow_enable(TIMER1);

		timer_enable(TIMER1);


}

void REIN_TIM_SIGNAL_COUNT_Init(void)
{
		timer_parameter_struct timer_initpara;
//		timer_oc_parameter_struct timer_ocinitpara;	
		rcu_periph_clock_enable(RCU_TIMER2);	
	  timer_deinit(TIMER2);
    timer_struct_para_init(&timer_initpara);
    timer_initpara.prescaler         = 108;
    timer_initpara.alignedmode       = TIMER_COUNTER_EDGE;
    timer_initpara.counterdirection  = TIMER_COUNTER_UP;
    timer_initpara.period            = 49;
    timer_initpara.clockdivision     = TIMER_CKDIV_DIV1;
    timer_initpara.repetitioncounter = 0;
    timer_init(TIMER2, &timer_initpara);

		timer_auto_reload_shadow_enable(TIMER2);
		timer_interrupt_enable(TIMER2, TIMER_INT_UP);
		nvic_irq_enable(TIMER2_IRQn, 0, 0);			
		timer_enable(TIMER2);	

}


