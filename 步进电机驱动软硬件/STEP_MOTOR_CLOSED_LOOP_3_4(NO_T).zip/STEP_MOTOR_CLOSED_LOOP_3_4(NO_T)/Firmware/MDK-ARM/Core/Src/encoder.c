
#include "encoder.h"
uint16_t *Read_QuickCali_DATA = (uint16_t*)ENCODER_CONFIG_ROM_ADDR;


/**
  * @brief  MT6816_SPI�ɼ���ʼ��
  * @param  NULL
  * @retval NULL
**/

void ENCODER_init(void)
{
	spi_parameter_struct spi_init_struct;
	rcu_periph_clock_enable(RCU_AF);	
	gpio_pin_remap_config(GPIO_SWJ_SWDPENABLE_REMAP,ENABLE);
	rcu_periph_clock_enable(RCU_GPIOA);

	rcu_periph_clock_enable(RCU_GPIOB);	

  rcu_periph_clock_enable(RCU_SPI0);
	gpio_pin_remap_config(GPIO_SPI0_REMAP,ENABLE);		
//	gpio_pin_remap_config(GPIO_PIN_15,ENABLE);
	gpio_init(GPIOA, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_15);	
	// PA4   ------> ENC_nCS

	
	/* SPI1 GPIO config: SCK/PA5, MISO/PA6, MOSI/PA7 */
    gpio_init(GPIOB, GPIO_MODE_AF_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_3 | GPIO_PIN_5);
    gpio_init(GPIOB, GPIO_MODE_IN_FLOATING, GPIO_OSPEED_50MHZ, GPIO_PIN_4);
	
	/* deinitilize SPI and the parameters */
    spi_i2s_deinit(SPI0);
    spi_struct_para_init(&spi_init_struct);

    /* SPI1 parameter config */
    spi_init_struct.trans_mode           = SPI_TRANSMODE_FULLDUPLEX;
    spi_init_struct.device_mode          = SPI_MASTER;
    spi_init_struct.frame_size           = SPI_FRAMESIZE_16BIT;
    spi_init_struct.clock_polarity_phase = SPI_CK_PL_LOW_PH_2EDGE;
    spi_init_struct.nss                  = SPI_NSS_SOFT;
    spi_init_struct.prescale             = SPI_PSC_8;
    spi_init_struct.endian               = SPI_ENDIAN_MSB;

    spi_init(SPI0, &spi_init_struct);
	
		spi_enable(SPI0);
		gpio_bit_reset(GPIOA,GPIO_PIN_15);
}

static uint16_t bsp_enc_spi_rw(uint16_t dat)
{
    uint16_t res;
		SPI_CS_ENABLE=0;
		while(spi_i2s_flag_get(SPI0, SPI_FLAG_TBE) == RESET);

    spi_i2s_data_transmit(SPI0, dat);
		while(spi_i2s_flag_get(SPI0, SPI_FLAG_RBNE) == RESET);

    res = spi_i2s_data_receive(SPI0);

    return res;
}
uint16_t a = 0,c = 0;
uint32_t sample_data = 0;
uint16_t ReadValue(void)
{
	uint16_t data_t[2];
	
	data_t[0] = 0x8300;
	data_t[1] = 0x8400;			
	bsp_enc_spi_rw(data_t[0]);
 	a = bsp_enc_spi_rw(0xffff);//0x12/0xff*100k
	SPI_CS_ENABLE = 1;
	bsp_enc_spi_rw(data_t[1]);	
	c = bsp_enc_spi_rw(0xffff);//0x12/0xff*100k	
	SPI_CS_ENABLE = 1;
	
	sample_data = ((a & 0x00FF) << 8) | (c & 0x00FF);
	sample_data = sample_data>>2;
	return sample_data;
}
uint16_t angle_ = 0;
void REIN_MT6816_Get_AngleData(void)
{
	mt6816.angle_data = ReadValue();
	mt6816.rectify_angle = Read_QuickCali_DATA[mt6816.angle_data];

}

