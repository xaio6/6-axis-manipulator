

#include "peripheral.h"
#include "can.h"

void port_init(void)
{
	rcu_periph_clock_enable(RCU_GPIOA);
	
	gpio_init(GPIOA, GPIO_MODE_OUT_PP, GPIO_OSPEED_2MHZ, GPIO_PIN_12);	// 
	gpio_bit_reset(GPIOA,GPIO_PIN_12);	
	if(can_read.op_state == 0x01)
	{
		magnet_1;
	}else if(can_read.op_state == 0x00)
	{
		magnet_0;
	}

}


