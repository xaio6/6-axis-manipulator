#include "user_config.h"
#include "can.h"
#include "tim.h"
#include "hw_elec.h"
#include "motor_control.h"


short SAVE_Config(USERCONFIG *User_config)
{     
	short *P_User_config = &User_config->motor_ENABLE;
	fmc_state_enum status;
  fmc_unlock();
	ob_unlock();
	// Erase
  fmc_flag_clear(FMC_FLAG_BANK0_END|FMC_FLAG_BANK0_WPERR|FMC_FLAG_BANK0_PGERR);
	status = fmc_page_erase(USR_CONFIG_ROM_ADDR);
	fmc_flag_clear(FMC_FLAG_BANK0_PGERR | FMC_FLAG_BANK0_WPERR | FMC_FLAG_BANK0_END );
	
	if(status == FMC_READY)
		{
			// Program
			for(int i=0; i<sizeof(USERCONFIG)/2; i++)
					{
					status = fmc_halfword_program(USR_CONFIG_ROM_ADDR+i*2,(*P_User_config));
					fmc_flag_clear(FMC_FLAG_BANK0_PGERR | FMC_FLAG_BANK0_WPERR | FMC_FLAG_BANK0_END);
					P_User_config++;
					if(status != FMC_READY)
						{
							break;
						}
					}
		}
	
	fmc_lock();
	return (status != FMC_READY);

}
unsigned short STM32_FLASH_ReadHalfWord(unsigned int faddr)
{
	return *(unsigned short*)faddr; 
} 
void CONFIG_Read(unsigned int ReadAddr,USERCONFIG *User_config)   	
{
	unsigned short i;
	short *P_User_config = &User_config->motor_ENABLE;
	for(i=0;i<sizeof(USERCONFIG)/2;i++)
	{
		*P_User_config=STM32_FLASH_ReadHalfWord(ReadAddr);
		ReadAddr+=2;
		P_User_config++;
	}
}
void Read_FLASH_config()
{

	CONFIG_Read(USR_CONFIG_ROM_ADDR,&user_config);
	
	can_read.motor_ENABLE 				 							 = user_config.motor_ENABLE;	
	can_read.calib_flag													 = user_config.calib_flag;
	g_transmit_message.tx_sfid									 = user_config.motor_address;
	can_read.motor_address											 = user_config.motor_address;
	if(can_read.calib_flag != 2)
	{
		g_transmit_message.tx_sfid								 = 7;
	}
	can_read.control_mode 						 				   = user_config.control_mode;
	
	can_read.op_state	 	 									  		 = user_config.op_state;
	can_read.traj_accel													 = user_config.traj_accel;
	can_read.traj_decel													 = user_config.traj_accel;
	can_read.vel_max														 = user_config.vel_max;
	can_read.dce_kp															 = user_config.dce_kp;     // 
	can_read.dce_ki															 = user_config.dce_ki;  //    
  can_read.dce_kv															 = user_config.dce_kv;     // 
  can_read.dce_kd															 = user_config.dce_kd;  //    
	
	

}
void PWMC_switch_on_pwm(void)
{
	/* Set all duty to 50% */
	timer_channel_output_state_config(TIMER1, TIMER_CH_2, TIMER_CCX_ENABLE);
	timer_channel_output_state_config(TIMER1, TIMER_CH_3, TIMER_CCX_ENABLE);
}
void PWMC_switch_down_pwm(void)
{
	REIN_HW_Elec_SetSleep();
	timer_channel_output_state_config(TIMER1, TIMER_CH_2, TIMER_CCX_DISABLE);
	timer_channel_output_state_config(TIMER1, TIMER_CH_3, TIMER_CCX_DISABLE);
}
void Write_FLASH_config()
{
	PWMC_switch_down_pwm();
	user_config.motor_ENABLE 				 					  = 1;		
	user_config.motor_address										= 7;
	user_config.calib_flag											= 2;
	can_read.calib_flag                         = 2;
	user_config.control_mode 										= 0;
	user_config.op_state 	 											= 1;
	user_config.traj_accel 											= 1000;	
	user_config.traj_decel 											= 1000;		
	user_config.vel_max 	 											= 18773;	
	user_config.dce_kp 													= 300;	
	user_config.dce_ki 	 												= 80;		
	user_config.dce_kv 													= 300;	
	user_config.dce_kd 	 												= 250;			
	user_config.current_max											= 5000;	
	user_config.protect_under_voltage 				  = 32000;			
	SAVE_Config(&user_config);

}
short Parameter_Save(void)
{
	user_config.motor_ENABLE 				 					  = can_read.motor_ENABLE;		
	user_config.motor_address 									= can_read.motor_address;
	user_config.control_mode 										= can_read.control_mode;
	user_config.op_state 	 											= can_read.op_state;
	user_config.traj_accel 											= can_read.traj_accel;	
	user_config.traj_decel 											= can_read.traj_decel;		
	user_config.vel_max 	 											= 0;	
	user_config.dce_kd 													= can_read.dce_kd;	
	user_config.dce_kp 	 												= can_read.dce_kp;		
	user_config.dce_kv 													= can_read.dce_kv;	
	user_config.dce_ki 	 												= can_read.dce_ki;			
	user_config.current_max											= can_read.current_max;		
	user_config.protect_under_voltage 				  = 32000;			
	
	SAVE_Config(&user_config);
	return 2;
}
