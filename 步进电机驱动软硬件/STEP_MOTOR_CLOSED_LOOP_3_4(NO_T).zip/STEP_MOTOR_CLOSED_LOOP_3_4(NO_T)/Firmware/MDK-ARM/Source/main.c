/******
	************************************************************************
	******
	** @project : ����Ŀ���ݿ�ԴXDrive_Step����
	** @author  : unlir (֪��֪��)
	******
	** @address : ԭ��Ŀ��ַhttps://github.com/unlir/XDrive
	******
	************************************************************************
******/
#include "can.h"
#include "main.h"
#include "peripheral.h"
#include "encoder.h"
#include "encode_cali.h"
#include "motor_control.h"
#include "hw_elec.h"
#include "USER_Config.h"
#include "motor_control.h"

Control_DCE_Typedef           dce;
MT6816_Typedef	              mt6816;
CAN_READ 										  can_read;
CAN_State                     can_state;
USERCONFIG 	                  user_config;
Motor_Control_Typedef 				motor_control;		
CanFrame 										  canrecevie_frame;
can_receive_message_struct    g_receive_message;
can_trasnmit_message_struct   g_transmit_message;


int main(void)
{

 	nvic_priority_group_set(NVIC_PRIGROUP_PRE2_SUB2);

	Motor_Control_Init();
	Read_FLASH_config();
	port_init();
	ENCODER_init();
	CAN_init();
	REIN_TIM_HwElec_Init();
	REIN_TIM_SIGNAL_COUNT_Init();	
    while(1)
			{	
				


			}
			
}

void Error_Handler(void)
{
	__disable_irq();

	while(1){}
}
