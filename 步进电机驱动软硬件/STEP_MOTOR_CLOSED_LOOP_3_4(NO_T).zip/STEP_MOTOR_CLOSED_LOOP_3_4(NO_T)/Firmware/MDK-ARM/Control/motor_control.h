/******
	************************************************************************
	******
	** @project : XDrive_Step
	** @brief   : Stepper motor with multi-function interface and closed loop function. 
	** @brief   : 具有多功能接口和闭环功能的步进电机
	** @author  : unlir (知不知啊)
	** @contacts: QQ.1354077136
	******
	** @address : https://github.com/unlir/XDrive
	******
	************************************************************************
	******
	** {Stepper motor with multi-function interface and closed loop function.}
	** Copyright (c) {2020}  {unlir(知不知啊)}
	** 
	** This program is free software: you can redistribute it and/or modify
	** it under the terms of the GNU General Public License as published by
	** the Free Software Foundation, either version 3 of the License, or
	** (at your option) any later version.
	** 
	** This program is distributed in the hope that it will be useful,
	** but WITHOUT ANY WARRANTY; without even the implied warranty of
	** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	** GNU General Public License for more details.
	** 
	** You should have received a copy of the GNU General Public License
	** along with this program.  If not, see <http://www.gnu.org/licenses/>.
	******
	************************************************************************
******/

/*****
  ** @file     : control_config.c/h
  ** @brief    : 电机控制
  ** @versions : 2.2.3
  ** @time     : 2020/09/15
  ** @reviser  : unli (HeFei China)
  ** @explain  : null
*****/

#ifndef MOTOR_CONTROL_H
#define MOTOR_CONTROL_H

#ifdef __cplusplus
extern "C" {
#endif

//引用端口定义
#include "kernel_port.h"

/****************************************  DCE控制(位置控制)  ****************************************/
/****************************************  DCE控制(位置控制)  ****************************************/
typedef struct{
	//配置
	#define De_DCE_KP	1200		//默认KP
	#define De_DCE_KI	600		//默认KI
	#define De_DCE_KV	100		//默认KIV
	#define De_DCE_KD	50		//默认KD
	bool		valid_kp, valid_ki, valid_kv, valid_kd;	//参数有效标志
	//控制参数(基本部分)
	int32_t		p_error, v_error;		//误差记录
	int32_t		op, oi, od;					//输出
	int32_t		i_mut, i_dec;				//小积分处理
	int32_t		out;								//输出
}Control_DCE_Typedef;
//初始化
void Control_DCE_Init(void);
void Control_DCE_To_Electric(int32_t _location, int32_t _speed);



/****************************************  Motor_Control  ****************************************/
/****************************************  Motor_Control  ****************************************/
/**
  * 控制器状态
**/
typedef enum{
	Control_State_Stop				= 0x00,	//停止
	Control_State_Finish			= 0x01,	//任务完成
	Control_State_Running			= 0x02,	//任务执行中
	Control_State_Overload		= 0x03,	//过载
	Control_State_Stall				= 0x04,	//堵转
}Motor_State;

/**
  * Motor_Control类结构体定义
**/
typedef struct{
	//配置(模式)
	bool can_flag;	
	char M_dir;
	//模式
	int32_t	  soft_location;
	int32_t	  soft_speed;
	int32_t 	last_soft_speed;
	//读取
	int32_t		real_lap_location;				//读取单圈位置
	int32_t		real_lap_location_last;		//读取单圈位置
	int32_t		real_location;						//读取位置
	int32_t		real_location_last;				//读取位置
	//估计
	int32_t		est_speed_mut;						//估计速度倍值(放大n倍)(mut有积分作用,不会有精度损失)
	int32_t		est_speed;								//估计速度
	int32_t		est_lead_location;				//估计位置超前位置
	int32_t		est_lead_location_debug;	//估计位置超前位置
	int32_t		est_location;							//估计位置
	int32_t		est_error;								//估计位置误差
	int32_t   real_speed;


	//输出
	int32_t		foc_location;		//FOC矢量位置
	int32_t		foc_current;		//FOC矢量大小
	
	uint32_t	Tplan_time_inc;	//T计时器
	//状态
	Motor_State		state;			//统一的电机状态
}Motor_Control_Typedef;
extern  Motor_Control_Typedef 				motor_control;				//控制主结构
extern  Control_DCE_Typedef dce;


void Motor_Control_Callback(void);

//任务执行
void Motor_Control_Init(void);											//电机控制初始化

void Motor_Control_Clear_Integral(void);						//清除积分

int32_t Motor_Control_AdvanceCompen(int32_t _speed);//超前角补偿

#ifdef __cplusplus
}
#endif

#endif



