

/*****
  ** @file     : control_config.c/h
  ** @brief    : 控制配置
  ** @versions : 2.2.3
  ** @time     : 2020/09/15
  ** @reviser  : unli (HeFei China)
  ** @explain  : null
*****/

//Oneself
#include "control_config.h"

///**
//  * @brief  控制静态配置
//  * @param  NULL
//  * @retval NULL
//**/
//void Control_Config_Init_Static(void)
//{
//}

///**
//  * @brief  控制动态配置 
//  * @param  NULL
//  * @retval NULL
//**/
//void Control_Config_Init_Dynamic(void)
//{
//}
