
//Oneself
#include "motor_control.h"
//Base_Drivers
#include "hw_elec.h"
#include "encoder.h"
//Control
#include "user_config.h"
#include "can.h"


/**
  * @brief  控制器DCE初始化
  * @param  NULL
  * @retval NULL
**/
void Control_DCE_Init(void)
{

	//控制参数(基本部分)
	dce.p_error = 0;	dce.v_error = 0;
	dce.op = 0;				dce.oi = 0;			dce.od = 0;	
	dce.i_mut = 0;		dce.i_dec = 0;
	dce.out = 0;
}
int time_inc;
int32_t speed_clc()
{
	
	float t_hz = (float)time_inc/20000.0f;
	int speed_out = motor_control.last_soft_speed + (can_read.traj_accel*51200)*t_hz;
	if(speed_out>= abs(motor_control.soft_speed))
	{
		
		return motor_control.soft_speed;
	}else{ 
				time_inc++;
				if(motor_control.soft_speed<0)
				{
					return -speed_out; 
				}else{return speed_out; }
				}
	

}

/**
  * @brief  DCE电流控制
  * @param  _location 控制位置
  * @param  _speed    控制速度
  * @retval NULL
**/

void Control_DCE_To_Electric(int32_t _location, int32_t _speed)
{
	//误差
	dce.p_error = _location - motor_control.real_location;

	if(abs(dce.p_error) <= 1300)
	{
		motor_control.soft_speed =0;
		_speed = 0;
		time_inc = 0;
	if(abs(dce.p_error) <= 200)
	{
		motor_control.state = Control_State_Finish;
	}
	}else{
		motor_control.state = Control_State_Running;
	}

	dce.v_error = (_speed - motor_control.est_speed) >> 7;	//速度误差缩小至1/128
	if(dce.p_error > ( 3200))	dce.p_error = ( 3200);				//限制位置误差在1/16圈内(51200/16)
	if(dce.p_error < (-3200))	dce.p_error = (-3200);
	if(dce.v_error > ( 4000))	dce.v_error = ( 4000);				//限制速度误差在10r/s内(51200*10/128)
	if(dce.v_error < (-4000))	dce.v_error = (-4000);
	//op输出计算
	dce.op     = ((can_read.dce_kp) * (dce.p_error));
	//oi输出计算
	dce.i_mut += ((can_read.dce_ki) * (dce.p_error));
	dce.i_mut += ((can_read.dce_kv) * (dce.v_error));
	dce.i_dec  = (dce.i_mut >> 7);
	dce.i_mut -= (dce.i_dec << 7);
	dce.oi    += (dce.i_dec);
	if(dce.oi >      (  Current_Rated_Current << 10 ))	dce.oi = (  Current_Rated_Current << 10 );	//限制为额定电流 * 1024
	else if(dce.oi < (-(Current_Rated_Current << 10)))	dce.oi = (-(Current_Rated_Current << 10));	//限制为额定电流 * 1024
	//od输出计算
	dce.od = ((can_read.dce_kd) * (dce.v_error));
	//综合输出计算
	dce.out = (dce.op + dce.oi + dce.od) >> 10;
	if(dce.out > 			Current_Rated_Current)		dce.out =  Current_Rated_Current;
	else if(dce.out < -Current_Rated_Current)		dce.out = -Current_Rated_Current;

	//输出FOC电流
	motor_control.foc_current = dce.out;
	//输出FOC位置
	if(motor_control.foc_current > 0)			motor_control.foc_location = motor_control.est_location + Move_Divide_NUM;
	else if(motor_control.foc_current < 0)	motor_control.foc_location = motor_control.est_location - Move_Divide_NUM;
	else																		motor_control.foc_location = motor_control.est_location;
	//输出任务到驱动
	REIN_HW_Elec_SetDivideElec(motor_control.foc_location, motor_control.foc_current);
}



/**
  * @brief  电机控制初始化
  * @param  NULL
  * @retval NULL
**/
void Motor_Control_Init(void)
{	

	//读取
	motor_control.real_lap_location = 0;
	motor_control.real_lap_location_last = 0;
	motor_control.real_location = 0;
	motor_control.real_location_last = 0;
	//估计
	motor_control.est_speed_mut = 0;
	motor_control.est_speed = 0;
	motor_control.est_lead_location = 0;
	motor_control.est_location = 0;
	motor_control.est_error = 0;

	//输出
	motor_control.foc_location = 0;
	motor_control.foc_current = 0;
	//状态
	motor_control.state = Control_State_Stop;		

}

/**
  * @brief  控制器任务回调
  * @param  NULL
  * @retval NULL
**/

int inc = 0;int test = 0;
void Motor_Control_Callback(void)
{
	/************************************ 首次进入控制回调 ************************************/
	/************************************ 首次进入控制回调 ************************************/
	static bool first_call = true;
	if(first_call)
	{

		//读取(为了方便将XDrive代码移植到软件编码器,将位置读取初始化部分全部放置在此处运行)
		motor_control.real_lap_location				= mt6816.rectify_angle;
		motor_control.real_lap_location_last	= mt6816.rectify_angle;
		motor_control.real_location						= mt6816.rectify_angle;
		motor_control.real_location_last			= mt6816.rectify_angle;
		motor_control.soft_location							= mt6816.rectify_angle;
		//第一次运行强制退出
 		first_call = false;
		return;
	}
	
	/************************************ 数据采集 ************************************/
	/************************************ 数据采集 ************************************/
	int32_t		sub_data;		//用于各个算差
	//读取单圈位置
	motor_control.real_lap_location_last = motor_control.real_lap_location;
	motor_control.real_lap_location = mt6816.rectify_angle;
	//回环检测
	sub_data = motor_control.real_lap_location - motor_control.real_lap_location_last;
	if(sub_data > (Move_Pulse_NUM >> 1))				sub_data -= Move_Pulse_NUM;
	else if(sub_data < -(Move_Pulse_NUM >> 1))	sub_data += Move_Pulse_NUM;
	//读取位置
	motor_control.real_location_last = motor_control.real_location;
	motor_control.real_location += sub_data;
	
	/************************************ 数据估计 *      ***********************************/
	/************************************ 数据估计 ************************************/
	//估计速度
	motor_control.est_speed_mut += (	((motor_control.real_location - motor_control.real_location_last) * (CONTROL_FREQ_HZ))//rps
																	+ ((int32_t)(motor_control.est_speed  << 5) - (int32_t)(motor_control.est_speed)));

	motor_control.est_speed      = (motor_control.est_speed_mut >> 5);																	//(取整)(向0取整)(保留符号位)
	motor_control.est_speed_mut  = ((motor_control.est_speed_mut) - ((motor_control.est_speed << 5)));	//(取余)(向0取整)(保留符号位)
	
	motor_control.real_speed 		 = ((motor_control.real_location - motor_control.real_location_last) * (CONTROL_FREQ_HZ));
	
	//估计位置
	motor_control.est_lead_location = Motor_Control_AdvanceCompen(motor_control.est_speed);
	motor_control.est_location = motor_control.real_location + motor_control.est_lead_location;
	

	if(can_read.motor_ENABLE == 1)
	{
			Control_DCE_To_Electric(motor_control.soft_location, motor_control.soft_speed);
	}	

}

/**
  * @brief  设清除积分
  * @param  NULL
  * @retval NULL
**/
void Motor_Control_Clear_Integral(void)
{
	
	//DCE
	dce.i_mut = 0;
	dce.i_dec = 0;
	dce.oi = 0;
	
}


/**
  * @brief  超前角补偿
  * @param  _speed:补偿速度
  * @retval 补偿角度
**/
int32_t Motor_Control_AdvanceCompen(int32_t _speed)
{
	/******************** !!!!! 重要1：本补偿表提取自DPS系列代码                                                  !!!!! ********************/
	/******************** !!!!! 重要2：由于源于其他传感器数据，本补偿表并不完全适合TLE5012和MT6816                !!!!! ********************/
	/******************** !!!!! 重要3：由于测量传感器的最佳补偿曲线十分费时繁琐，作者并不准备在近期进行校准表测量 !!!!! ********************/

	int32_t compen;
	if(_speed < 0){
		if(_speed > -100000)				compen = 0;
		else if(_speed > -1300000)	compen = (((_speed +  100000) * 262) >> 20) -   0;
		else if(_speed > -2200000)	compen = (((_speed + 1300000) * 105) >> 20) - 300;
		else												compen = (((_speed + 2200000) *  52) >> 20) - 390;
		if(compen < -430)						compen = -430;
	}
	else{
		if(_speed < 100000)					compen = 0;																					//(      0,  0) ~ ( 100000,  0)
		else if(_speed <  1300000)	compen = (((_speed -  100000) * 262) >> 20) +   0;	//( 100000,  0) ~ (1300000,300)
		else if(_speed <  2200000)	compen = (((_speed - 1300000) * 105) >> 20) + 300;	//(1300000,300) ~ (2200000,390)
		else												compen = (((_speed - 2200000) *  52) >> 20) + 390;	//(2200000,390) ~ 
		if(compen > 430)						compen = 430;
	}
	return compen;
}



